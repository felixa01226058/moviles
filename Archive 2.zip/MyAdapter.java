package com.example.gdaalumno.practicaexamen;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by gdaalumno on 10/18/16.
 */
public class MyAdapter extends BaseAdapter  {

    private Activity activity;
    private ArrayList<Amigos> amigos;

    public MyAdapter(Activity activity, ArrayList<Amigos> amigos) {
        this.activity = activity;
        this.amigos = amigos;
    }

    @Override
    public int getCount() {
        return amigos.size();
    }

    @Override
    public Object getItem(int position) {
        return amigos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        if(view == null){
            view = activity.getLayoutInflater().inflate(R.layout.row,null);
        }

        TextView nombre = (TextView) view.findViewById(R.id.name);
        TextView hobby =(TextView) view.findViewById(R.id.hobby);

        nombre.setText(amigos.get(position).getNombre());
        hobby.setText(amigos.get(position).getHobby());

        return view;
    }
}
