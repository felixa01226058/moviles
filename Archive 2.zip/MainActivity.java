package com.example.gdaalumno.practicaexamen;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements fragmento.OnFragmentInteractionListener,JSONCallback{

    JSONRequest request;
    ArrayList<Amigos> amigos;
    fragmento fragmentito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmentito = (fragmento) getFragmentManager().findFragmentById(R.id.fragment);
    }

    public void loadJson(View v){
        request = new JSONRequest(this);
        request.execute("https://raw.githubusercontent.com/felixa01226058/moviles/master/amiguitos.json");
    }

    @Override
    public void callBack(JSONObject jo) {

        try{
            amigos = new ArrayList<Amigos>();
            JSONArray arreglo = jo.getJSONArray("amigos");

            for (int i = 0 ; i<arreglo.length();i++){
                JSONObject objecto = arreglo.getJSONObject(i);
                Amigos amigo = new Amigos(objecto.getString("name"),objecto.getString("hobby"),objecto.getString("age"),objecto.getString("phone"),objecto.getString("address"));
                amigos.add(amigo);
            }


        }catch(Exception e){

        }

        fragmentito.LlenarLista(amigos);

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    public void changeActivity(View v){
        Intent i = new Intent(v.getContext(),Main2Activity.class);
        startActivity(i);
    }
}
