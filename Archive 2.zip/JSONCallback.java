package com.example.gdaalumno.practicaexamen;

import org.json.JSONObject;

/**
 * Created by gdaalumno on 10/18/16.
 */
public interface JSONCallback {
    void callBack(JSONObject jo);

}
