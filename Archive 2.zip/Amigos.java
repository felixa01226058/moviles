package com.example.gdaalumno.practicaexamen;

/**
 * Created by gdaalumno on 10/18/16.
 */
public class Amigos {
    private String Nombre,Hobby,Edad,Telefono,Direccion;

    public Amigos(String nombre, String edad, String hobby, String direccion, String telefono) {
        Nombre = nombre;
        Edad = edad;
        Hobby = hobby;
        Direccion = direccion;
        Telefono = telefono;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getHobby() {
        return Hobby;
    }

    public void setHobby(String hobby) {
        Hobby = hobby;
    }

    public String getEdad() {
        return Edad;
    }

    public void setEdad(String edad) {
        Edad = edad;
    }
}
